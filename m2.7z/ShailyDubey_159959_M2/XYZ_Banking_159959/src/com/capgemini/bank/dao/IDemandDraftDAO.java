package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;

//Interface for Data Accessing Logic
public interface IDemandDraftDAO
{
	int addDemandDraftDetails (DemandDraft demandDraft);
	DemandDraft getDemandDraftDetails (int transactionId);
}
