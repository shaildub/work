package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

//Service utility Interface
public interface IDemandDraftService
{
	int addDemandDraftDetails (DemandDraft demandDraft);
	DemandDraft getDemandDraftDetails (int transactionId);
}
