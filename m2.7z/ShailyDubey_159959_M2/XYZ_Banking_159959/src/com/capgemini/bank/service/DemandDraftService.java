package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

//Service utility class
public class DemandDraftService implements IDemandDraftService
{
	public int addDemandDraftDetails (DemandDraft demandDraft)
	{
//		commission calculation
		if(demandDraft.getDd_amount()<=5000 && demandDraft.getDd_amount()>=0)
			demandDraft.setDd_commission(10);
		else if(demandDraft.getDd_amount()>=5001 && demandDraft.getDd_amount()<=10000)
			demandDraft.setDd_commission(41); 
		else if(demandDraft.getDd_amount()>=10001 && demandDraft.getDd_amount()<=100000)
			demandDraft.setDd_commission(51);
		else if(demandDraft.getDd_amount()>=100001 && demandDraft.getDd_amount()<=500000)
			demandDraft.setDd_commission(306);
		
//		returning commission
		return demandDraft.getDd_commission();
	}
	
	public DemandDraft getDemandDraftDetails (int transactionId)
	{
		
		return null;		
	}
}
