import java.util.Scanner;

public class ter
{
	public static void main(String z[])
	{
		Scanner sc = new Scanner(System.in);
		int a, b, c;
		System.out.println("Enter 2 values:");
		a = sc.nextInt();
		b = sc.nextInt();
		c = (a>b)?a:b;
		System.out.println("Greatest is ; "+c);
	}
}