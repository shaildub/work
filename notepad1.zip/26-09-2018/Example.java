public class Example
{
	public static void main(String z[])
	{
		System.out.println("Even Numbers");		//odd even numbers
		for(int i=0; i<=100; i++)
			if(i%2==0)
				System.out.println(i);
		System.out.println("Odd Numbers");
		for(int i=0; i<=100; i++)
			if(i%2!=0)
				System.out.println(i);
		
		System.out.println("------------");
		
		Integer l=0;							//900 800 700
		Integer a[] = new Integer[15];
		for(int i=999; i>99; i--)
			if(i%100==0)
			{
				a[l]=i;
				l++;
			}
		for(int i=0; i<l; i++)
			System.out.println(a[i]);
	}
}