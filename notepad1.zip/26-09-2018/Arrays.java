import java.util.Scanner;

public class Arrays
{
	public static void main(String z[])
	{
		int a[] = new int[5];
		Scanner s = new Scanner(System.in);
		int b[] = {36, 45, 92, 71};
		a[0] = 10;
		a[3] = 20;
		a[2] = 30;
		a[2] = 40;
		a[1] = 50;
		System.out.println("Enter last no. : ");
		a[4] = s.nextInt();
		System.out.println("-----------------");
		System.out.println("Last no. : "+ a[4]);
		System.out.println("-----------------");
		for(int i=0; i<a.length; i++)
			System.out.println(a[i]);
		System.out.println("-----------------");
		for(int i=0; i<b.length; i++)
			System.out.println(b[i]);
	}
}