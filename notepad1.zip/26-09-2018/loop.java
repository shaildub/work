public class loop
{
	public static void main(String b[])
	{
		int i=0;
		
		for(i=1; i<11; i++)
			System.out.println("2 * "+i+" = "+2*i);		//table of 2
		
		System.out.println("--------------------");
		
		for(i=90; i>=65; i--)
			System.out.println((char)i);				//z to a
		
		System.out.println("--------------------");
		
		i=65;
		while(i<=90)
		{
			System.out.println((char)i);
			i++;
		}
		
		System.out.println("--------------------");
		
		i=65;
		do
		{
			System.out.println((char)i);
			i++;
		}while(i<=90);
	}
}