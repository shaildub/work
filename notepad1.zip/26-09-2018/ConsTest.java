public class ConsTest
{
	ConsTest(char a, char b)
	{
		System.out.println("a"+"b");
		System.out.println('a'+'b');
		System.out.println(a+b);
		System.out.println("a"+'b');
		System.out.println(a+""+b);
	}
	ConsTest(int a, int b)
	{
		System.out.println("a"+"b");
		System.out.println('a'+'b');
		System.out.println(a+b);
		System.out.println("a"+'b');
		System.out.println(a+""+b);
	}
	ConsTest(float a)
	{
		System.out.println("a"+1);
		System.out.println('a'+1);
		System.out.println(a+1);
		System.out.println(a+""+1);
	}
	public static void main(String...a)
	{
		ConsTest ct1 = new ConsTest('a','b');
		ConsTest ct2 = new ConsTest(97,98);
		ConsTest ct3 = new ConsTest(99);
	}
}