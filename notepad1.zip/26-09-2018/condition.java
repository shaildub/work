public class condition
{
	public static void main(String z[])
	{
		int i=1;
		if(i==0)
			System.out.println("False");
		else
			System.out.println("True");
	}
}