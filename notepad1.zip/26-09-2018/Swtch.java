import java.util.Scanner;

public class Swtch
{
	public static void main(String z[])
	{
		Scanner sc = new Scanner(System.in);
		
		int i;
		System.out.println("Enter a number(7/9) : ");
		i = sc.nextInt();
		switch(i)
		{
			case 7: System.out.println("Yes"); break;
			case 9: System.out.println("No"); break;
			default: System.out.println("Wrong");
		}
		
		char c;
		System.out.println("Enter a character(Y/N) : ");
		c = sc.next().charAt(0);
		switch(c)
		{
			case 'Y': System.out.println("yEs"); break;
			case 'N': System.out.println("nOo"); break;
			default: System.out.println("Wrong");
		}
		
		String s;
		System.out.println("Enter a string(YE/NO) : ");
		s = sc.next();
		switch(s)
		{
			case "YE": System.out.println("YES"); break;
			case "NO": System.out.println("NOO"); break;
			default: System.out.println("Wrong");
		}
	}
}