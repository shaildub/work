import java.util.Scanner;

public class Strings
{
	public static void main(String z[])
	{
		String a="Srinivas", b="Kolaparthi", c;
		System.out.println("length = "+a.length());
		System.out.println("upper case = "+a.toUpperCase());
		System.out.println("lower case = "+a.toLowerCase());
		Scanner s = new Scanner(System.in);
		System.out.println("Enter: ");
		c = s.next();
		if(a.equals(c))
			System.out.println("Same");
		else
			System.out.println("Different");
		System.out.println("character at : "+a.charAt(5));
		System.out.println("code point : "+a.codePointAt(6));
	}
}