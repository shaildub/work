public class Byte
{
	public static void main(String z[])
	{
		byte a=35, b=44;
		System.out.println(a+b);
		System.out.println("-----------------");
		byte c=a+b;									//in byte, operations not possible
		System.out.println(c);
		System.out.println("-----------------");
		byte d=135, e=-1;							//byte range -126 to 127
		System.out.println(d+e);
		System.out.println("-----------------");
		byte f=2, g=3;
		f = f + g*3 + 5*6 + f*g;					//in byte, operations not possible
		System.out.println(f);
	}
}