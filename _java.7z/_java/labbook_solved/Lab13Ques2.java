package com.capgemini.LabBook;

import java.time.LocalDateTime;

public class Lab13Ques2 implements Runnable
{

	@Override
	public void run() 
	{
		while(true)
		{
			LocalDateTime d = LocalDateTime.now();
			int hh= d.getHour();
			int mm= d.getMinute();
			int ss = d.getSecond();
			System.out.println(hh +" : "+mm +" : "+ss);
			try
			{
				Thread.sleep(10000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			
		}
		
	}

	public static void main(String[] args)
	{
		Lab13Ques2 ll = new Lab13Ques2();
		Thread t = new Thread(ll);
		t.start();

	}

}
