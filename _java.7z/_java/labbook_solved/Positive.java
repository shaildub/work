package com.assignment;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Positive {

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int num=Integer.parseInt(args[0]);
		
		
		if(num>=0)
			System.out.println("positive number");
		else
			System.out.println("negative number");
		


	}

}
