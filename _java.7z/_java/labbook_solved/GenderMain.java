package com.assignment;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class GenderMain {
	enum Gender{
		M,F
	}
	public static void main(String[] args) {
		Gender r1=Gender.M;
		Gender r2=Gender.F;
		
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("person Details");
			try {
				PersonDetails d=new PersonDetails();
				System.out.println("Enter the First Name");
				String fname=br.readLine();
				d.setFname(fname);
				System.out.println("Enter the Last Name");
				String lname=br.readLine();
				d.setLname(lname);
				
				System.out.println("Enter the Phone number");
				long phno=Long.parseLong(br.readLine());
				d.setPhno(phno);
				
				System.out.println("Enter the Gender");
				char gender=br.readLine().charAt(0);
				if (gender=='M'|| gender=='m')
				{
					d.setGender(r1);
				}
				else if(gender=='F'|| gender=='f')
				{
					d.setGender(r2);
				}
				else {
					System.out.println("Enter M or F");
				}
				System.out.println(d);
				
				} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
	
		
	}

