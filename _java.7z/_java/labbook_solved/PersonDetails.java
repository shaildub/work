package com.assignment;

import com.assignment.GenderMain.Gender;

public class PersonDetails {
	private String fname;
	private String lname;
	private char gender;
	private long phno;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender2) {
		this.gender = gender2;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "PersonDetails [fname=" + fname + ", lname=" + lname + ", gender=" + gender + ", phno=" + phno + "]";
	}
	public void setGender(Gender r1) {
		// TODO Auto-generated method stub
		
	}
	

}
