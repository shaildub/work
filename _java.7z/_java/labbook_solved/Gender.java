package com.assignment;

public class Gender {
	private String fname;
	private String lname;
	private Gender gender;
	private long phno;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "Gender [fname=" + fname + ", lname=" + lname + ", gender=" + gender + ", phno=" + phno + "]";
	}
	

}
