package com.capgemini.LabBook;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Lab13Ques1FileProgram 
{

	public static void main(String[] args) 
	{
		FileInputStream fis = new FileInputStream("source.txt");
		FileOutputStream fos = new FileOutputStream("target.txt");
		Lab13Ques1 lb = new Lab13Ques1(fis,fos);
		Thread t = new Thread(lb);
		t.start();

	}

}
