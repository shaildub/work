package com.capgemini.LabBook;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Calendar;
import java.util.Scanner;
import java.util.TimeZone;
public class Lab3Ques6
{
	/*
	public void zonetime(String s)
	{
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(s));
		Date currentDate = calendar.getTime();
		System.out.println(currentDate);
	}

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the time zone");
		String s = sc.next();
		Lab3Ques6 lb6 = new Lab3Ques6();
		lb6.zonetime(s);
	}
	*/
	public static void getCurrentTimeWithTimeZone(){
	    System.out.println("-----Current time of a different time zone using LocalTime-----");
	    ZoneId zoneId = ZoneId.of("Australia/Sydney");
	    LocalTime localTime=LocalTime.now(zoneId);
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
	    String formattedTime=localTime.format(formatter);
	    System.out.println("Current time of the day: " + formattedTime);
	 
	}
	public static void main(String[] args) 
	{
		Lab3Ques6 lb =new Lab3Ques6();
		lb.getCurrentTimeWithTimeZone();
	}

}
