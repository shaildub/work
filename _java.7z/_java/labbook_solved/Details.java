package com.assignment;

public class Details {

	public static void main(String[] args) {
		int age=20;
		String a="Divya";
		String b="Bharathi";
		String c="F";
		Double d=85.55;
		System.out.println("Person Details:");
		System.out.println("_____________");
		System.out.println("First Name:"+a);
		System.out.println("Last Name:"+b);
		System.out.println("Gender:"+c);
		System.out.println("Age:"+age);
		System.out.println("Weight:"+d);

	}

}
