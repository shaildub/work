package com.assignment;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PersonDetailsMain {
	public static void main(String[] args) {
		DetailsD n=new DetailsD();
		n.getDetails();
		
	}
}
class DetailsD{
	void getDetails() {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("person Details");
		try {
			PersonDetails d=new PersonDetails();
			System.out.println("Enter the First Name");
			String fname=br.readLine();
			d.setFname(fname);
			System.out.println("Enter the Last Name");
			String lname=br.readLine();
			d.setLname(lname);
			System.out.println("Enter the Phone number");
			long phno=Long.parseLong(br.readLine());
			d.setPhno(phno);
			System.out.println("Enter the Gender");
			char gender=(char)br.read();
			d.setGender(gender);
			System.out.println(d);
			
			
			} catch (Exception e) {
			e.printStackTrace();
		}
	}
}