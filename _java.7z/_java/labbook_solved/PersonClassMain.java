package com.assignment;

public class PersonClassMain {
public static void main(String[] args) {
	PersonClass p=new PersonClass();
	p.setFname("Divya");
	p.setLname("Bharathi");
	p.setGender('F');
	System.out.println("person Details:");
	System.out.println("____________");
	System.out.println("First Name:"+p.getFname());
	System.out.println("Last Name:"+p.getLname());
	System.out.println("Gender:"+p.getGender());
	
}
}
