package com.capgemini.core;

public class Clone implements Cloneable
{
	public static void main(String z[])
	{
		Clone c = new Clone();
		Clone cc = (Clone) c.Clone();
	}
}
