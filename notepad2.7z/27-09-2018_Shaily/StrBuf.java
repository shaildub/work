package com.capgemini.core;

public class StrBuf
{
	public static void main(String z[])
	{
		StringBuffer s = new StringBuffer("sd");
		System.out.println(s.capacity());
		System.out.println(s.length());
		s.ensureCapacity(40);
		System.out.println(s.capacity());
		System.out.println(s.append("Srini"));
		System.out.println(s.insert(4, 41.5f));
		System.out.println(s.insert(6, "  "));
		System.out.println(s.reverse());
		System.out.println(s.delete(4, 10));
		System.out.println(s.deleteCharAt(3));
		System.out.println(s.replace(2, 6, "sd"));
	}
}
