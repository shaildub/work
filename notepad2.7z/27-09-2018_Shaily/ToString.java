package com.capgemini.core;

public class ToString
{
	public static void main(String[] args)
	{
		ToString ts = new ToString();
		System.out.println(ts);
	}
	public String toString()
	{
		return "Hey";
	}
}
